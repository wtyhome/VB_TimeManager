﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form1
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(form1))
        Me.MainTextbox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MainCB = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextYear = New System.Windows.Forms.TextBox()
        Me.TextMonth = New System.Windows.Forms.TextBox()
        Me.TextDay = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TextNow = New System.Windows.Forms.Label()
        Me.Timer = New System.Windows.Forms.Timer(Me.components)
        Me.Label7 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'MainTextbox
        '
        Me.MainTextbox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.MainTextbox.Enabled = False
        Me.MainTextbox.Font = New System.Drawing.Font("新細明體", 72.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.MainTextbox.Location = New System.Drawing.Point(163, 44)
        Me.MainTextbox.Multiline = True
        Me.MainTextbox.Name = "MainTextbox"
        Me.MainTextbox.Size = New System.Drawing.Size(170, 107)
        Me.MainTextbox.TabIndex = 0
        Me.MainTextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("新細明體", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label1.Location = New System.Drawing.Point(18, 67)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(156, 64)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "剩下"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("新細明體", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label2.Location = New System.Drawing.Point(339, 94)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 37)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "天"
        '
        'MainCB
        '
        Me.MainCB.Font = New System.Drawing.Font("微軟正黑體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.MainCB.FormattingEnabled = True
        Me.MainCB.Location = New System.Drawing.Point(29, 173)
        Me.MainCB.Name = "MainCB"
        Me.MainCB.Size = New System.Drawing.Size(273, 42)
        Me.MainCB.TabIndex = 3
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(320, 175)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(94, 39)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "刪除此項"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextName
        '
        Me.TextName.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TextName.Location = New System.Drawing.Point(86, 229)
        Me.TextName.Name = "TextName"
        Me.TextName.Size = New System.Drawing.Size(233, 40)
        Me.TextName.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("新細明體", 14.0!)
        Me.Label3.Location = New System.Drawing.Point(33, 239)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 19)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "事項"
        '
        'TextYear
        '
        Me.TextYear.Font = New System.Drawing.Font("新細明體", 14.0!)
        Me.TextYear.Location = New System.Drawing.Point(86, 278)
        Me.TextYear.Name = "TextYear"
        Me.TextYear.Size = New System.Drawing.Size(77, 30)
        Me.TextYear.TabIndex = 7
        '
        'TextMonth
        '
        Me.TextMonth.Font = New System.Drawing.Font("新細明體", 14.0!)
        Me.TextMonth.Location = New System.Drawing.Point(195, 278)
        Me.TextMonth.Name = "TextMonth"
        Me.TextMonth.Size = New System.Drawing.Size(46, 30)
        Me.TextMonth.TabIndex = 8
        '
        'TextDay
        '
        Me.TextDay.Font = New System.Drawing.Font("新細明體", 14.0!)
        Me.TextDay.Location = New System.Drawing.Point(281, 278)
        Me.TextDay.Name = "TextDay"
        Me.TextDay.Size = New System.Drawing.Size(38, 30)
        Me.TextDay.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("新細明體", 14.0!)
        Me.Label4.Location = New System.Drawing.Point(52, 281)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 19)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "年"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("新細明體", 14.0!)
        Me.Label5.Location = New System.Drawing.Point(161, 281)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 19)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "月"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("新細明體", 14.0!)
        Me.Label6.Location = New System.Drawing.Point(247, 281)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 19)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "日"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(335, 254)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(79, 46)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "新增"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TextNow
        '
        Me.TextNow.AutoSize = True
        Me.TextNow.Font = New System.Drawing.Font("新細明體", 14.0!)
        Me.TextNow.Location = New System.Drawing.Point(143, 20)
        Me.TextNow.Name = "TextNow"
        Me.TextNow.Size = New System.Drawing.Size(59, 19)
        Me.TextNow.TabIndex = 14
        Me.TextNow.Text = "Label7"
        '
        'Timer
        '
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("新細明體", 14.0!)
        Me.Label7.Location = New System.Drawing.Point(33, 20)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(104, 19)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "目前時間："
        '
        'form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(420, 351)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TextNow)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TextDay)
        Me.Controls.Add(Me.TextMonth)
        Me.Controls.Add(Me.TextYear)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextName)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MainCB)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MainTextbox)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "form1"
        Me.Text = "日期管理器 MadeBy羿丞"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MainTextbox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents MainCB As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TextName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextYear As System.Windows.Forms.TextBox
    Friend WithEvents TextMonth As System.Windows.Forms.TextBox
    Friend WithEvents TextDay As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents TextNow As System.Windows.Forms.Label
    Friend WithEvents Timer As System.Windows.Forms.Timer
    Friend WithEvents Label7 As System.Windows.Forms.Label

End Class
