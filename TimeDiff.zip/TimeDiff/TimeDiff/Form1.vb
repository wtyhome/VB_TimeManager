﻿Public Class form1
    Dim timeData As New List(Of Date)
    Dim nowDay As Date
    Dim targetDay As Date
    Dim ItemChanged As Boolean
    Sub Swap(ByRef A, ByRef B)
        Dim TEMP = A
        A = B
        B = TEMP
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ItemChanged = False
        Dim tempDay As Date
        Dim TimeInput As New IO.StreamReader("c:\vbtime.txt")
        '資料讀入
        While (Not TimeInput.EndOfStream)
            Dim timeTemp() As String = Split(TimeInput.ReadLine, ",")
            MainCB.Items.Add(timeTemp(0))
            tempDay = "#" & timeTemp(2) & "/" & timeTemp(3) & "/" & timeTemp(1) & "#"
            timeData.Add(tempDay)
            EventSort()
        End While
        nowDay = Now.ToString
        If (MainCB.Items.Count > 0) Then MainCB.SelectedIndex = 0
        TextNow.Text = Now.ToString
        Timer.Interval = 1000
        Timer.Start()
        TimeInput.Close()
    End Sub
    Sub EventSort()
        Dim DayLeft As New List(Of Long)
        For i = 0 To timeData.Count - 1
            targetDay = timeData(i)
            DayLeft.Add(DateDiff(DateInterval.Day, nowDay, targetDay))
        Next
        For i = 0 To timeData.Count - 1 - 1
            For j = 0 To timeData.Count - 1 - 1 - i
                If (DayLeft(j) > DayLeft(j + 1)) Then
                    Swap(DayLeft(j), DayLeft(j + 1))
                    Swap(MainCB.Items(j), MainCB.Items(j + 1))
                    Swap(timeData(j), timeData(j + 1))
                End If
            Next
        Next
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        If (ItemChanged = False) Then End
        Dim QuestionSave As Integer = MsgBox("資料是否寫回文本", MsgBoxStyle.YesNoCancel)
        If (QuestionSave = 2) Then
            e.Cancel = True
        End If
        If (QuestionSave = 6) Then
            Dim timeOutput As New IO.StreamWriter("c:\vbtime.txt", False, System.Text.Encoding.Unicode)
            For i = 0 To timeData.Count - 1
                timeOutput.WriteLine(MainCB.Items(i) & "," & timeData(i).Year & "," & timeData(i).Month & "," & timeData(i).Day)
            Next
            timeOutput.Close()
        End If
    End Sub
    Private Sub MainCB_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MainCB.SelectedIndexChanged
        targetDay = timeData(MainCB.SelectedIndex)
        If (DateDiff(DateInterval.Day, nowDay, targetDay) = 0) Then
            MainTextbox.Text = DateDiff(DateInterval.Hour, nowDay, targetDay)
            Label2.Text = "分"
        Else
            MainTextbox.Text = DateDiff(DateInterval.Day, nowDay, targetDay)
            Label2.Text = "天"
        End If

    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (MainCB.Items.Count = 0) Then
            MsgBox("Why you delete nothing?")
        Else
            ItemChanged = True
            timeData.RemoveAt(MainCB.SelectedIndex)
            MainCB.Items.RemoveAt(MainCB.SelectedIndex)
            EventSort()
            If (MainCB.Items.Count > 0) Then
                MainCB.SelectedIndex = 0
            Else
                MainCB.Text = ""
                MainTextbox.Text = ""
            End If
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If (TextName.Text = "" Or TextYear.Text = "" Or TextMonth.Text = "" Or TextDay.Text = "") Then
            MsgBox("Nothing inside of it,what the hell are you")
        Else
            ItemChanged = True
            Dim EventName, EventYear, EventDay, Eventmonth As String
            Dim index As Integer = timeData.Count
            Dim tempDate As Date
            EventName = TextName.Text
            EventYear = TextYear.Text
            Eventmonth = TextMonth.Text
            EventDay = TextDay.Text
            tempDate = String.Format("#{0}/{1}/{2}#", Eventmonth, EventDay, EventYear)
            timeData.Add(tempDate)
            MainCB.Items.Add(EventName)
            MainCB.SelectedIndex = index
            EventSort()
        End If
    End Sub
    Private Sub Timer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer.Tick
        nowDay = Now
        TextNow.Text = nowDay.ToString()
    End Sub
End Class
